exports.fakeDB=[
    {
        id:0,
        email:'m@gmail.com',
        password:'$2a$10$ZzeRm0wneMJAFHDKHEqQ6usKQUXbuAN41LXEiSor7C/QVdUfQJcUS'  
    }
];